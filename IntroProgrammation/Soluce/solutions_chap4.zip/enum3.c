#include <stdio.h>

/*
 * Chapitre 4: Structures de Données
 * Enumération -- Exercice 3 (mois de l'année)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

typedef enum{
  janvier=1, fevrier, mars, avril, mai,
  juin, juillet, aout,septembre, octobre,
  novembre, decembre
}Mois;

int main(){
  printf("%d %d\n", janvier, fevrier);
}//fin programme
