/*
 * Chapitre 4: Structures de Données
 * Enumération -- Exercice 4 (jeu de cartes)
 *
 * @author: Benoit Donnet (ULiege)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <stdlib.h>

typedef enum{
  coeur=0, carreau, trefle, pique
}Couleur;

typedef enum{
  sept=7, huit, neuf, dix, valet, dame, roi, as
}Niveau;

typedef struct{
  Couleur coul;
  Niveau niv;
}carte;


/*
 * Analyse du Problème
 *  - données en entrée: le jeu de cartes
 *  - output: le jeu de cartes mélangé
 *
 * Découpe en sous-problèmes:
 *  - SP 1: initialisation du jeu de cartes
 *  - SP 2: mélanger
 *  - SP 3: affichage des cartes mélangées
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 */

int main(){
  //dimension du jeu de cartes => 32 cartes
  const unsigned short N = 32;

  const unsigned short NB_NIVEAU = 8;
  const unsigned short NB_COULEUR = 4;

  //Le jeu de cartes
  carte jeu[N];

  unsigned short i, j, ind1, ind2;

  /*
   * SP 1: initialiser le jeu de cartes
   * Ce sous-problème n'est pas indiqué dans l'énoncé mais est nécessaire.
   * En effet, quand on déclare une variable de type "tableau", il faut initialiser le contenu
   * de chacune des cases.  Dans ce cas-ci, il va falloir indiquer pour chaque carte ce qu'elle
   * est réellement, i.e., sa couleur et son niveau.
   *
   * On va remplir le jeu de cartes couleur par couleur, et niveau par niveau.  Cela signifique que:
   * - tab[0] va contenir le 7 de coeur (valeur 7 pour le champ niv, 0 pour le champ coul)
   * - tab[1] va contenir le 8 de coeur (valeur 8 pour le champ niv, 0 pour le champ coul)
   * - ...
   * - tab[7] va contenir l'as de coeur (valeur 14 pour le champ niv, 0 pour le champ coul)
   * - tab[8] va contenir le 7 de carreau (valeur 7 pour le champ niv, 1 pour le champ coul)
   * - ...
   * - tab[N-1] va contenir l'as de pique (valeur 14 pour le champ niv, 3 pour le champ coul)
   *
   * Le meilleur moyen de comprendre comment on gère les indices dans le tableau "jeu"
   * (et donc en tirer les invariants -- laissé à l'étudiant à titre d'exercice),
   * c'est de faire un dessin représentant le jeu de cartes.
   */
  for(i=0; i<NB_COULEUR; i++){
      for(j=0; j<NB_NIVEAU; j++){
          jeu[i*NB_NIVEAU + j].coul = i;
          jeu[i*NB_NIVEAU + j].niv = j+7;//bien faire attention que le premier niveau (carte 7) est équivalent à l'entier 7
      }//fin for - j
  }//fin for - i

  /*
   * SP 2: mélanger
   * Il y a plusieurs façons de procéder.  Nous avons implémenté ce sous-problème comme suit:
   * 1. tirer deux indices au hasard dans le jeu de cartes.  Les valeurs aélatoires doivent se trouver
   *    dans l'intervalle  [0, N-1].  La fonction rand() (définie dans stdlib.h) permet de donner un
   *    nombre aléatoire dans l'intervalle [0, +infini].  En "modulant" ce nombre par N (la dimension
   *    du jeu de cartes, on est certain qu'on reste dans les bornes du tableau.
   * 2. échanger les cartes stockées à ces 2 indices.  C'est ce qu'on appelle une opération de "swap".
   * 3. recommencer à 1. un certain nombre de fois (disons 200).
   * Attention, cette méthode a tendance à être "déterministe" (i.e., si on exécute plusieurs fois de
   * suite le programme, on  verra apparaître le même mélange).
   */
  for(i=0; i<200; i++){
      //tirage au sort des indices dans l'intervalle [0, N-1]
      ind1 = rand() % N;
      ind2 = rand() % N;

      //il suffit de "swapper" jeu[ind1] avec jeu[ind2]
      carte tmp = jeu[ind1];
      jeu[ind1] = jeu[ind2];
      jeu[ind2] = tmp;
  }//fin for - i

  /*
   * SP 3: affichage des cartes mélangées.
   */
  for(i=0; i<N; i++)
      printf("%d %d %d\n", i, jeu[i].coul, jeu[i].niv);
}//fin programme
