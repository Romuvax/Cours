/*
 * Chapitre 4: Structures de Données
 * Tableaux Multi. -- Exercice 5 (Somme de 2 matrices)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembrze 2023
 */

#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: 2 matrices d'entiers, de dimension N*M
 *  - Output: affichage de la matrice C = A + B
 *  - Caractérisation des Inputs
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 10;
 *      M est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short M = 10;
 *      A est une matrice de valeurs entières.
 *        int A[N][M];
 *      B est une matrice de valeurs entières.
 *        int B[N][M];
 *
 * Analyse du Problème:
 *  - SP1: remplissage de la matrice {A} (possibilité de raffiner en 2 SPs)
 *  - SP2: remplissage de la matrice {B} (possibilité de raffiner en 2 SPs)
 *  - SP3: calcul de {C} = {A} + {B} (possibilité de raffiner en 2 SPs)
 *  - SP4: affichage de la matrice {C} (possibilité de raffiner en 2 SPs)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */


 int main(){
   const unsigned short N = 10;
   const unsigned short M = 10;
   int A[N][M];
   int B[N][M];
   int C[N][M];
   unsigned short i,j;

   /*
   * SP1: remplissage de la matrice A.
   */
   /*
    * SP1.a: énumération & remplissage des lignes de la matrice
    *
    *
    * Invariant Graphique:
    *
    *               |0                    M-1|M
    *               +------------------------+ ––
    *              0|                        |   |
    *               |                        |   | matrice remplie au clavier
    *               ...        ...         ...   |
    *  A:        i-1|                        | __|
    *            ------------------------------------
    *              i|                        | --
    *               ...        ...         ...   |
    *            N-1|                        |   |  encore à remplir
    *               +------------------------+ ––
    *              N
    *
    * Fonction de Terminaison: N-i
    */
   for(i=0; i<N; i++){
     /*
      * SP1.b: remplissage des colonnes de la ligne d'indice i
      *
      *
      * Invarint Graphique:
      *
      *              |0         |j         M-1|M
   	  *              +----------+-------------+
   	  *       A[i]:  |          |             |
   	  *              +----------+-------------+
   	  *               <--------> <----------->
   	  *                 rempli       à remplir
   	  *                 au clavier
      *
      *
      * Fonction de Terminaison: M-j
      */
     for(j=0; j<M; j++){
       printf("Elément[%hu][%hu] : ", i, j);
       scanf("%d", &A[i][j]);
     }//fin for - j
   }//fin for - i

   /*
   * SP2: remplissage de la matrice B.
   */
   /*
    * SP2.a: énumération & remplissage des lignes de la matrice
    *
    *
    * Invariant Graphique:
    *
    *               |0                    M-1|M
    *               +------------------------+ ––
    *              0|                        |   |
    *               |                        |   | matrice remplie au clavier
    *               ...        ...         ...   |
    *  B:        i-1|                        | __|
    *            ------------------------------------
    *              i|                        | --
    *               ...        ...         ...   |
    *            N-1|                        |   |  encore à remplir
    *               +------------------------+ ––
    *              N
    *
    * Fonction de Terminaison: N-i
    */
   for(i=0; i<N; i++){
     /*
      * SP2.b: remplissage des colonnes de la ligne d'indice i
      *
      *
      * Invariant Graphique:
      *
      *              |0         |j         M-1|M
   	  *              +----------+-------------+
   	  *       B[i]:  |          |             |
   	  *              +----------+-------------+
   	  *               <--------> <----------->
   	  *                 rempli       à remplir
   	  *                 au clavier
      *
      *
      * Fonction de Terminaison: M-j
      */
     for(j=0; j<M; j++){
       printf("Elément[%hu][%hu] : ", i, j);
       scanf("%d", &B[i][j]);
     }//fin for - j
   }//fin for - i

   /*
   * SP3: C = A + B
   *
   * L'Invariant peut facilement être tiré de la formule donnée dans l'énoncé.
   */
   for(i=0; i<N; i++){
     for(j=0; j<M; j++){
       C[i][j] = A[i][j] + B[i][j];
     }//fin for - j
   }//fin for - i

   /*
   * SP4: affichage du résultat
   *
   * Invariant(s) & Fonction(s) de Terminaison:
   *    cfr. Exercice 1 sur les tableaux multidimensionnels
   */
   printf("Matrice C :\n");
   for(i=0; i<N; i++){
     for(j=0; j<M; j++)
      printf("%3d", C[i][j]);
     printf("\n");
   }//fin for - i
}//fin programme
