/*
 * Chapitre 4: Structures de Données
 * Tableaux Uni. -- Exercice 4 (Evaluation Polynôme via le schéma de Horner)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: un tableau représentant les coefficients du polynôme ainsi que
 *           le degré maximum du polynôme
 *  - Output: évaluation du polynôme affichée à l'écran
 *  - Caractérisation des Inputs
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 5;
 *      coeff est un tableau de nombres réels (float ou double -- ici nous choisissons float)
 *        float coeff[N+1];
 *        la dimension de coeff est de N+1 car il faut penser au terme libre (exposant 0)
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau des coefficients (énumération et action)
 *  - SP2: lecture de x au clavier (lecture au clavier)
 *  - SP3: Schéma d'Horner (réalisation d'un action)
 *  - SP4: affichage du résultat (affichage à l'écran)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */

 int main(){
   const unsigned short N = 5;
   //tableau des coefficients de mon polynôme (degré N+1)
   float coeff[N+1];

   //valeur pour laquelle il faut calculer le polynôme
   float x;

   //résultat du calcul
   float res;

   short i;

   /*
   * SP 1: remplir le tableau {coeff} avec {N} valeurs entières lues au
   * clavier.
   *
   * Invariant Graphique:
   *
   *        |0         |i         N-1|N
   *        +----------+-------------+
   * coeff: |          |             |
   *        +----------+-------------+
   *         <--------> <----------->
   *           rempli       encore
   *         au clavier    à remplir
   *
   *
   * Fonction de Terminaison: N-i
   */
   printf("Remplissage des coefficients du polynome: \n");
   i=0;
   while(i<N+1){
     printf("Entrez la valeur du coefficient pour le degré %d: ", (N-i));
     scanf("%f", &coeff[i]);
     i++;
   }//fin while - i

   /*
   * SP 1: lecture de x au clavier
   */
   printf("Entrez la valeur de X: \n");
   scanf("%f", &x);

   /*
   * SP 3: calcul du polynôme à l'aide du schema d'Horner.
   *
   * l'invariant est assez évident sur base de la formule du schéma
   * d'Horner
   */
   res = 0;
   i = N;
   while(i>=0){
     res = x*res+coeff[i];
     i--;
   }//fin while - i

   //SP 4: Affichage du résultat
   printf("Le Résultat: %f\n", res);
 }//fin programme
