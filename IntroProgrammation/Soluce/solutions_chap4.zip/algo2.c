/*
 * Chapitre 4: Structures de Données
 * Algo. tableaux -- Exercice 2 (Renversement de tableau)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Défintion du Problème:
 *  - Input: un tableau à N valeurs entières
 *  - Output: affichage à l'écran du tableau renversé
 *            les éléments du tableau sont affichés entre crochets.
 *  - Caractérisation des Inputs
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsgined short N = 20;
 *      tab est un tableau d'entiers
 *        int tab[N];
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau tab (énumération et action)
 *  - SP2: renversement de tab dans un tableau intermédiaire renverse (réalisation d'une action)
 *  - SP3: affichage de renverse (affichage à l'écran)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 */

int main(){
  const unsigned short N = 20;
  int tab[N];
  int renverse[N];

  unsigned short i;

  /*
   * SP 1: remplir le tableau {tab} avec {N} valeurs entières lues au
   * clavier.
   *
   * Invariant Graphique:
	 *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
   *
	 *
	 * Fonction de Terminaison: N-i
   */
  i = 0;
  while(i<N){
    printf("Entez la %deme valeur du tableau: ", i+1);
    scanf("%d", &tab[i]);
    i++;
  }//fin while - i

  /*
   * SP2: renversement du tableau tab dans renverse
   *
   *
   * Définition SP2:
   *  - Input: tab, un tableau de N valeurs entières (obtenus via SP1)
   *  - Output: le contenu de tab est renversé dans renverse
   *  - Caractérisation des Inputs:
   *    tab, N (cfr. Définition Problème)
   *    reverse, tableau à N valeurs entières
   *      int reverse[N];
   *
   *
   * Représentation graphique de l'Output du SP2:
   *
   *       |0                    N-1|N
	 *       +------------------------+
	 * tab:  |                        |
	 *       +------------------------+
	 *        <--------------------->
	 *       déjà renversé dans reverse
   *        <--------------------->
	 *                inchangé
   *
   *            |0                    N-1|N
	 *            +------------------------+
	 * renverse:  |                        |
	 *            +------------------------+
	 *             <---------------------->
   *                   contenu de tab renversé
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          déjà       encore
	 *        renversé    à renverser
   *        dans renverse
   *        <--------------------->
	 *                inchangé
   *
   *            |0        i|         N-1|N
	 *            +----------+-------------+
	 * renverse:  |          |             |
	 *            +----------+-------------+
	 *             <--------> <----------->
   *                à            rempli par renversement de tab
   *              renverser
   *
   *
   * Fonction de Terminaison: N-i
   */
  i = 0;
  while(i<N){
    renverse[N-1-i] = tab[i];
    i++;
  }//fin while

  /*
   * SP3: affichage de renverse
   *
   *
   * Invariant Graphique:
   *            |0         |i         N-1|N
	 *            +----------+-------------+
	 * renverse:  |          |             |
	 *            +----------+-------------+
	 *             <--------> <----------->
   *              affiché        encore à afficher
   *              à l'écran
   *             <--------------------->
	 *                    inchangé
   *
   *
   * Fonction de Terminaison: N-i
   */
  printf("[ ");
  i = 0;
  while(i<N){
    printf("%d ", renverse[i]);
    i++;
  }//fin while - i

  printf("]\n");
}//fin programme
