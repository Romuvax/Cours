/*
 * Chapitre 4: Structures de Données
 * Enumération -- Exercice 1 (booléen)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Pour rappel, les valeurs booléennes (vrai/faux) sont traitées, en C, comme des entiers.
 * L'entier 0 désigne le faux, 1 le vrai.
 * Il s'agit ici d'associer une valeur entière à un nom symbolique, i.e., VRAI=1, FAUX=0.
 * Naturellement, on se tourne vers les énumérations.
*/
typedef enum{
  FAUX, VRAI
}Booleen;

int main(){
  printf("%d\n", FAUX);
  printf("%d\n", VRAI);
}//fin programme
