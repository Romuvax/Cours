/*
 * Chapitre 4: Structures de Données
 * Enumération -- Exercice 2 (jour de la semaine)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

typedef enum{
  lundi=1, mardi, mercredi, jeudi, vendredi, samedi, dimanche
}Semaine;

int main(){
  printf("%d %d\n", lundi, dimanche);
}//fin programme
