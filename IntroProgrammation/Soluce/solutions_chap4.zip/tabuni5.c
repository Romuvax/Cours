/*
 * Chapitre 4: Structures de Données
 * Tableaux Uni. -- Exercice 5 (Décalagle Tableau)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: un tableau à N valeurs entières (ordre croissant)
 *  - Output: le tableau, avec la valeur insérée, est affiché à l'écran.
 *            les éléments du tableau sont affichés entre crochets.
 *  - Caractérisation des Inputs
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 10;
 *      A est un tableau d'entiers
 *        int A[N+1];
 *        la dimension de A est de N+1 comme indiqué dans l'énoncé.
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau A (énumération et action)
 *  - SP2: lire la valeur de x au clavier (lecture au clavier)
 *  - SP3: trouver la position de x dans A (réalisation d'une action)
 *  - SP4: Insertion de la nouvelle valeur à la bonne position dans A et décalage (réalisation d'une action)
 *  - SP5: afficher le contenu du tableau (affichage à l'écran)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4 -> SP5
 */

 int main(){
   const short N = 10;

   //le tableau de taille N+1 et de N éléments
   int A[N+1];

   //la valeur à insérer
   int x;

   //position dans le tableau à laquelle on va insérer la nouvelle valeur;
   int pos = -1;

   int valeur, tmp, c=1;

   unsigned short i;

   /*
   * SP 1: remplir le tableau {A} avec {N} valeurs entières lues au
   * clavier.  Attention, le remplissage doit se faire avec des valeurs croissantes.
   *
   * je choisis de remplir le tableau avec les valeurs suivantes: 1, 3, 5, ...
   *
   * Invariant Graphique:
   *
   *       |0         |i          |N|N+1
   *       +----------+-----------+-+
   * A:    |          |             |
   *       +----------+-----------+-+
   *        <--------> <---------->
   *          rempli       encore
   *          avec des    à remplir
   *          valeurs croissantes
   *  A[N] non rempli
   *
   *
   * Fonction de Terminaison: N-i
   */
   i=0;
   while(i<N){
     A[i] = c;
     c += 2;
     i++;
   }//fin while - i

   //SP 2: lecture de la valeur de x au clavier
   printf("Entrez la valeur à insérer dans le tableau: ");
   scanf("%d", &x);

   /*
   * SP 3: trouver la position dans le tableau à laquelle insérer la nouvelle
   * donnée.  On utilise une boucle 'while' (pour changer)
   *
   * Définition du SP3 :
   *  - Input: le tableau A, rempli avec N valeurs croissantes, et x (donnés par les SP1 et 2)
   *  - Output: i, la position où insérer x dans A
   *  - Caractérisation des Inputs:
   *    A, N, x (cfr. SP1, 2)
   *    i, entier
   *      int i;
   *
   *
   * Représentation graphique de l'Output du SP3
   *
   *       |0          | i |           |N|N+1
   *       +-----------+---|-----------+-+
   * A:    |           |   |             |
   *       +-----------+---+-----------+-+
   *        <---------> <------------->
   *           . < x         . >= x
   *        <----------------------->
   *         inchangé et trié croissant
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i          |N|N+1
   *       +----------+-----------+-+
   * A:    |   .<=x   |             |
   *       +----------+-----------+-+
   *        <--------> <---------->
   *                    encore à parcourir
   *        <----------------------->
   *         inchangé et trié croissant
   * A[N] non exploré
   *
   *
   * Fonction de Terminaison: N-i
   */
   i=0;
   while(i<N && A[i]<=x)
      i++;

   //je suis sorti de la boucle: soit parce que A[i]>x, soit parce qu'on atteint la
   //dernière valeur du tableau.  Dans tous les cas, i est la position recherchée
   pos = i;
   printf("position: %d\n", pos);

   /*
   * SP 4: insérer la nouvelle valeur et décaler, si nécessaire, tous les éléments
   * ultérieurs d'une position
   * ce SP revient à un 'swap' des valeurs du tableau deux à deux entre
   * [pos ... N] (avec pos>=0)
   *
   *
   * Définition SP4:
   *  - Input: A, N et pos, la position où insérer x (donnés par les SP précédents)
   *  - Output: x inséré dans tab[pos] et contenu ultérieur du tableau décalé d'une position
   *  - Objets Utilisés:
   *      A, N, x (cfr. SP précédents)
   *      pos, entier (la position où insérer)
   *        int pos;
   *
   *
   * Représentation graphique de l'Output du SP4:
   *
   *       |0                      N|N+1
   *       +------------------------+
   * A:    |                        |
   *       +------------------------+
   *        <----------------------->
   *              x inséré à tab[pos]
   *        <----------------------->
   *             trié croissant
   *
   *
   * Invariant Graphique:
   *
   *       |0   |pos  |i           N|N+1
   *       +----+-----+-------------+
   * A:    |          |             |
   *       +----+-----+-------------+
   *             <----> <----------->
   *              déjà   encore à décaler
   *              décalé
   *              d'un pas vers la droite
   *        <----------------------->
   *             trié croissant
   *
   *
   * Fonction de Terminaison: N+1-i
   */
   valeur = x;
   i = pos;
   while(i<=N){
     tmp = A[i];
     A[i] = valeur;
     valeur = tmp;

     i++;
   }//end while - i

   /*
   * SP 5: affichage du contenu du tableau avec le format [ A[0] ... A[N] ]
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i           N|N+1
   *       +----------+-------------+
   * A:    |          |             |
   *       +----------+-------------+
   *        <--------> <------------>
   *          affiché       encore
   *          à            à afficher
   *          l'écran
   *
   *
   * Fonction de Terminaison: N+1-i
   */
   printf("[ ");
   for(i=0; i<=N; i++)
      printf("%d ", A[i]);
   printf("]\n");
 }//fin programme
