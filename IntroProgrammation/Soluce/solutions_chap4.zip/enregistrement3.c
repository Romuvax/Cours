/*
 * Chapitre 4: Structures de Données
 * Enregistrement -- Exercice 3 (gestion de stock)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

typedef struct{
  int reference;
  float prix;
  unsigned int quantite;
}Produit;

int main(){
  //Je crée un tableau de produit pour mon stock. L'indice O va
  //correspondre aux cartes mères, ..., l'indice 3 aux cartes graphiques.
  Produit stock[4];

  unsigned short choix, boucle=1;
  unsigned int quantite;

  //carte mère
  stock[0].reference = 1;
  stock[0].prix = 3.65;
  stock[0].quantite = 50;
  //processeur
  stock[1].reference = 2;
  stock[1].prix = 15.65;
  stock[1].quantite = 50;
  //barrettes mémoires
  stock[2].reference = 3;
  stock[2].prix = 5.5;
  stock[2].quantite = 50;
  //cartes graphiques
  stock[3].reference = 4;
  stock[3].prix = 8.65;
  stock[3].quantite = 50;

  do{
    printf("Menu de commande:\n");
    printf("\t1. Carte mère\n");
    printf("\t2. Processeur\n");
    printf("\t3. Barrette Mémoire\n");
    printf("\t4. Carte Graphique\n");
    printf("\t0. Quitter\n");
    printf("Entrez votre choix: ");

    scanf("%hu", &choix);

    switch(choix){
      case 0:
        //quitter
        printf("Merci d'avoir passé commande\n");
        boucle = 0;

        break;
      case 1:
        //carte mère
        printf("Entrez la quantité désirée: ");
        scanf("%u", &quantite);

        if(quantite>stock[0].quantite)
          printf("Stock insuffisant!\n");
        else{
          printf("Prix à payer: %f EUR\n", stock[0].prix*quantite);
          stock[0].quantite -= quantite;
        }

        break;
      case 2:
        //processeur
        printf("Entrez la quantité désirée: ");
        scanf("%u", &quantite);

        if(quantite>stock[1].quantite)
          printf("Stock insuffisant!\n");
        else{
          printf("Prix à payer: %f EUR\n", stock[1].prix*quantite);
          stock[1].quantite -= quantite;
        }

      break;
      case 3:
        //barrette mémoire
        printf("Entrez la quantité désirée: ");
        scanf("%u", &quantite);

        if(quantite>stock[2].quantite)
          printf("Stock insuffisant!\n");
        else{
          printf("Prix à payer: %f EUR\n", stock[2].prix*quantite);
          stock[2].quantite -= quantite;
        }

        break;
      case 4:
        //carte graphique
        printf("Entrez la quantité désirée: ");
        scanf("%u", &quantite);

        if(quantite>stock[3].quantite)
          printf("Stock insuffisant!\n");
        else{
          printf("Prix à payer: %f EUR\n", stock[3].prix*quantite);
          stock[3].quantite -= quantite;
        }

        break;
      default:
        printf("Mauvais choix!\n");
        break;
    }//fin switch
  }while(boucle);
}//fin programme
