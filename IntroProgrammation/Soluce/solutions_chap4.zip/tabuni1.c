/*
 * Chapitre 4: Structures de Données
 * Tableaux Uni. -- Exercice 1 (remplir un tableau et somme d'entiers)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: un tableau de N valeurs entières
 *  - Output: somme des éléments du tableau affichée à l'écran
 *  - Caractérisation des Inputs
 *  		N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *      	const unsigned short N = 10; (note: la valeur 10 est donnée à titre indicatif)
 *  		tab est un tableau d'entiers
 *      	int tab[N]
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau (énumération et action)
 *  - SP2: calcul de la somme (réalisation d'une action)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2
 *
 *
 * Définition du SP2
 *  - Input: tab, un tableau rempli avec N valeurs entières (obtenu du SP1)
 *  - Output: somme contient la somme des éléments de tab
 *  - Caractérisation des Inputs:
 *    tab, n (cfr. Définition du Problème)
 *    somme, entier (contient la somme cumulative)
 *      int somme;
 *
 *
 * Représentation graphique de l'Output du SP2:
 *
 *       |0                    N-1|N
 *       +------------------------+
 * tab:  |                        |
 *       +------------------------+
 *        <---------------------->
 *          somme= tab[0] + tab[1] + ... + tab[i-1]
 *        <----------------------->
 *                inchangé
 */

 int main(){
	 //Constante qui va définir la taille du tableau
	 const unsigned int N = 10;

	 //tableau d'entiers que nous allons manipuler
	 int tab[N];
	 int somme;

	 /*
	 * Code de remplissage du tableau.
	 *
	 * Invariant Graphique:
	 *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
   *
	 * Fonction de Terminaison: N-i
	 */
	 unsigned int i = 0;
	 while(i < N){
		 printf("Introduisez une valeur: ");
		 scanf("%d", &tab[i]);
		 i++;
	 }//fin while -- i

	 somme=0;
	 i = 0;
	 /*
	 * SP 2: calculer la somme des {N} éléments dans {tab}
	 *
	 * Invariant Graphique:
   *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          somme=       à sommer
	 *      tab[0] + tab[1] + ... + tab[i-1]
   *        <----------------------->
   *                inchangé
	 *
   *
	 * Fonction de Terminaison: N-i
	 */
	 while(i<N){
		 somme += tab[i];
		 i++;
	 }//fin while - i

	 printf("La somme est: %d\n", somme);
 }//fin programme
