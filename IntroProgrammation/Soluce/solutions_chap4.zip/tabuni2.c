/*
 * Chapitre 4: Structures de Données
 * Tableaux Uni. -- Exercice 2 (min et du max dans un tableau)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: un tableau à N valeurs entières
 *  - Output: minimum et maximum du tableau affichés à l'écran
 *  - Caractérisation des Inputs:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 10; (note: la valeur 10 est donnée à titre indicatif)
 *      tab est un tableau d'entiers
 *        int tab[N]
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau  (énumération et action)
 *  - SP2: recherche du min et du max (réaliation d'une action)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2
 *
 *
 * Définition SP2:
 *  - Input: tab, un tableau rempli avec N valeurs entières (obtenu du SP1)
 *  - Output: min contient le minimum dans tab, max contient le maximum dans tab
 *  - Caractérisation des Inputs
 *    tab, n (cfr. Définition du Problème)
 *    min, entier (le minimum)
 *      int min;
 *    max, entier (le maximum)
 *      int max;
 *
 *
 * Représentation graphique de l'Output du SP2:
 *
 *       |0                    N-1|N
 *       +------------------------+
 * tab:  |                        |
 *       +------------------------+
 *        <----------------------->
 *        min contient le minimum du tableau
 *        max contient le maximum du tableau
 *        <----------------------->
 *                inchangé
 */

 int main(){
   const unsigned int N = 10;
   int tab[N];
   int min, max;
   unsigned int i;

   /*
   * Code de remplissage du tableau.
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          rempli       encore
   *        au clavier    à remplir
   *
   *
   * Fonction de Terminaison: N-i
   */
   i = 0;
   while(i < N){
     printf("Introduisez une valeur: ");
     scanf("%d", &tab[i]);
     i++;
   }//fin while -- i

   min = tab[0];
   max = tab[0];
   i = 1;
   /*
   * SP 2: recherche du min et du max dans tab
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *        min et max     encore à parcourir
   *   max = MAX{tab[0], tab[1], ..., tab[i-1]}
   *   min = MIN{tab[0], tab[1], ..., tab[i-1]}
   *        <----------------------->
   *                inchangé
   *
   *
   * Fonction de Terminaison: N-i
   */
   while(i<N){
     if(tab[i]<min)
        min = tab[i];

     if(tab[i]>max)
        max = tab[i];

     i++;
   }//fin while - i

   printf("La valeur min est: %d\n", min);
   printf("La valeur max est: %d\n", max);
 }//fin programme
