/*
* Chapitre 4: Structures de Données
* Chaînes de Caractères -- Exercice 2 (afficher à l'envers une chaîne de caractères)
*
* @author: Benoit Donnet (ULiège)
* Mise à Jour: Septembre 2023
*/

#include <stdio.h>

/*
* Définition du Problème:
*  - Input: une chaîne de max 30 caractères
*  - Output: la chaîne de caractères est affichée à l'envers
*  - Caractérisation des Inputs
*      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
*        const unsigned short N = 30; (par définition de l'énoncé)
*      s est un tableau de caractères.
*        char s[N+1];
*
* Analyse du Problème:
*  - SP1: lire la chaîne s au clavier (lecture au clavier)
*  - SP2: déterminer la longueur utile de la chaîne de caractères (réalisation d'une action)
*  - SP3: retourner la chaîne (réalisation d'une action)
*
* Enchaînement des SPs:
*  SP1 -> SP2 -> SP3
*/

int main(){
  //dimension de la chaîne de caractères
  const unsigned short N = 30;

  //la chaîne de caractères
  char s[N+1];

  unsigned short lu, i;

  //SP 1: lecture de s au clavier
  printf("Entrez la chaîne de caractères (max. 30 caractères): ");
  scanf("%s", s);

  /*
   * SP 2: déterminer la longueur utile de la chaîne de caractères.
   *
   * L'utilisateur a entré, au plus, 30 caractères.  On va stocker dans 'lu' la
   * longueur utile (i.e., le nombre de caractères effectivement entré).
   *
   *
   * Invariant Graphique:
   *
	 *          |0         |lu         | N|N+1
	 *          +----------+-----------+--+
	 *      s:  |          |           |\0|
	 *          +----------+-----------+--+
	 *           <--------> <---------->
   *                          à parcourir
   *            s contient
   *            lu caractères utiles
	 *           <--------------------->
   *                  inchangé
   *
   * Fonction de Terminaison: N+1-lu
   */
  lu = 0;
  while(s[lu]!='\0')
      lu++;

  /*
   * SP 3: retourner la chaîne.
   * Il suffit de parcourir la chaîne à reculons, à partir de 'lu-1'
   *
   * Inv:
   *
   *          |0        i|      |lu   | N|N+1
	 *          +----------+------+-----+--+
	 *      s:  |          |      |     |\0|
	 *          +----------+------+-----+--+
   *          <---------> <----> <------>
   *            à afficher          non exploré
   *                        déjà affiché
   *           <-------------------->
   *                inchangé
   *
   *
   * Fonction de Terminaison: lu-i
   */
  i = lu-1;
  while(i>=0){
    printf("%c", s[i]);
    i--;
  }//fin while - i

  printf("\n");
}//fin programme
