/*
 * Chapitre 4: Structures de Données
 * Enregistrement -- Exercice 4 (point)
 *
 * @author: Benoit Donnet (ULg)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: un tableau de N points
 *  - Output: le contenu du tableau est affiché sur la sortie standard
 *  - Objets Utilisés:
 *  		N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *      	const unsigned short N = 10; (note: la valeur 10 est donnée à titre indicatif)
 *  		tab est un tableau de points
 *      	Point tab[N];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage du tableau
 *  - SP 2: affichage du tableau
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2
 *
 */

typedef struct{
  int num;
  float x;
  float y;
}Point;

int main(){
  //Dimension du tableau
  const unsigned short N = 10;

  //tableau de structure
  Point tab[N];

  unsigned short i;

  /*
   * SP 1: remplissage du tableau
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
   *
	 * Fonction de terminaison: N-i
   */
  for(i=0; i<N; i++){
      printf("Entrez les %dème valeurs: ", i+1);
      scanf("%d %f %f", &tab[i].num, &tab[i].x, &tab[i].y);
  }//fin for - i

  /*
   * SP 2: affichage du contenu du tableau
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          affiché       encore
	 *        à l'écran    à afficher
	 *        <---------------------->
   *              inchangé
	 *
   *
	 * Fonction de Terminaison: N-i
   */
  for(i=0; i<N; i++)
      printf("%d %f %f\n", tab[i].num, tab[i].x, tab[i].y);
}//fin programme
