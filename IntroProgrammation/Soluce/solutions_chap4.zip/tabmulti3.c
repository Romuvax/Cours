/*
 * Chapitre 4: Structures de Données
 * Tableaux Multi. -- Exercice 3 (matrice carrée unitaire)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: /
 *  - Output: affichage de la matrice identité
 *  - Caractérisation des Inputs
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 3;
 *      matUnitaire est une matrice (carrée) de valeurs entières.
 *        int matUnitaire[N][N];
 *
 * Analyse du Problème:
 *  - SP1: construction de la matrice carrée unitaire (peut être raffiné en 2 SPs)
 *  - SP2: affichage du résultat (peut être raffiné en 2 SPs)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2
 */

int main(){
  //dimension de la matrice
  const unsigned short N = 10;

  //la matrice unitaire
  int matUnitaire[N][N];

  unsigned short i, j;

  /*
   * SP1: construction de la matrice carrée unitaire
   *
   *
   * Invariant Graphique:
   *                   |0                    N-1|N
   *                  -+------------------------+ ––
   *                  0|                        |   |
   *                   |                        |   | matrice unité créée
   *                   ...        ...         ...   |
   *  matUnitaire:  i-1|                        | __|
   *                 --------------------------------
   *                  i|                        | --
   *                   ...        ...         ...   |
   *                N-1|                        |   |  encore à remplir
   *                  -+------------------------+ ––
   *                  N
   *
   *
   * Fonction de Terminaison: N-i
   */
  for(i=0; i<N; i++){
    /*
     * Remplissage de la ligne d'indice i
     *
     *
     * Invariant Graphique:
     *
     *                  |0         |j         N-1|N
  	 *                  +----------+-------------+
  	 * matUnitaire[i]:  |          |             |
  	 *                  +----------+-------------+
     *                   <--------> <----------->
     *                    rempli      à remplir
     *                    avec i==j
  	 *
     *
     * Fonction de Terminaison: N-j
     */
    for(j=0; j<N; j++)
      matUnitaire[i][j] = (i==j);

    /*
     * Note: l'instruction unique du corps de la boucle di-dessus:
     *  matUnitaire[i][j] = (i==j);
     * n'est pas forcément "jolie" mais assez pratique à écrire.
     * Elle est équivalent à ceci:
     * if (i == j)
     *      matUnitaire[i][j] = 1;
     * else
     *      matUnitaire[i][j] = 0;
     */
  }//fin for - i

  /*
   * SP2: affichage du résultat
   *
   * Invariant(s) & Fonction(s) de Terminaison:
   *    cfr. Exercice 1 sur les tableaux multidimensionnels
   */
  printf("Matrice unitaire de dimension %d :\n", N);
  for(i=0; i<N; i++){
    for(j=0; j<N; j++)
      printf("%3d", matUnitaire[i][j]);
    printf("\n");
  }//fin for - i
}//fin programme
