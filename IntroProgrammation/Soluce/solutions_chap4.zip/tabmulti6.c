/*
 * Chapitre 4: Structures de Données
 * Tableaux Multi. -- Exercice 6 (Recherche de point-cols)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */
#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: un matrice d'entiers de dimension NMAX*NMAX
 *  - Output: point-cols de la matrice affichés à l'écran
 *  - Caractérisation des Inputs
 *      NMAX est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short M = 50;
 *      A est une matrice de valeurs entières.
 *        int A[NMAX][NMAX];
 *
 * Analyse du Problème:
 *  - SP1: remplissage de la matrice {tab} (possibilité de raffiner en 2 SPs)
 *  - SP2: recherche du maximum sur une ligne
 *  - SP3: marquer tous les maxima sur la ligne
 *  - SP4: recherche du minimum sur une colonne
 *  - SP5: marquer tous les minimas sur une colonne
 *  - SP6: affichage des résultats (possibilité de raffiner en 2 SPs)
 *
 * Enchaînement des SPs:
 *  SP1 -> (SP2 -> SP3) -> (SP4 -> SP5) -> SP6
 */

 int main(){
   //dimension max des matrices
   const unsigned short NMAX = 50;

   //la matrice
   int A[NMAX][NMAX];

   // matrice indiquant les maxima des lignes
   int max[NMAX][NMAX];
   //matrice indiquant les minima des colonnes
   int min[NMAX][NMAX];

   //dimension des matrices.  Attention, 0<n,m<=nmAX
   unsigned short n, m;
   unsigned short i, j;

   //pour la détection des extréma
   int extrema;

   //compteur des points-cols
   unsigned int compteur;

   /*
   * SP1: remplir la matrice tab
   */
   printf("nombre de lignes   (max. %d) : ", NMAX);
   scanf("%hu", &n );
   printf("nombre de colonnes (max. %d) : ", NMAX);
   scanf("%hu", &m );
   for (i=0; i<n; i++){
     for (j=0; j<m; j++){
       printf("Elément[%hu][%hu] : ",i,j);
       scanf("%d", &A[i][j]);
     }//fin for - j
   }//fin for -i

   /*
   * Construction de la matrice d'extrema max qui indique les positions de tous les
   * maxima sur une ligne.
   * Plusieurs sous-problèmes:
   *   SP2: recherche du maximum sur une ligne
   *   SP3: marquer tous les maxima sur la ligne
   */
   for(i=0; i<n; i++){
     /*
     * SP2
     * Invariant Graphique:
     *
     *       |0         |j         m-1|m
     *       +----------+-------------+
     * A[i]: |          |             |
     *       +----------+-------------+
     *        <--------> <----------->
     *        extrema =     encore à parcourir
     *        MAX{A[i][0], A[i][1], ..., A[i][j-1]}
     *
     *
     * Fonction de Terminaison: m-j
     */
     extrema=A[i][0];
     for (j=1; j<m; j++){
       if (A[i][j] > extrema)
        extrema=A[i][j];
     }//fin for - j

     // SP3
     for (j=0; j<m; j++)
        max[i][j] = (A[i][j]==extrema);

     /*
     * Note: l'instruction unique du corps de la boucle: max[i][j] = (A[i][j]==extrema);
     * n'est pas forcément "jolie" mais assez pratique à écrire.
     * Elle est équivalent à ceci:
     * if (A[i][j]==extrema)
     *      max[i][j] = 1;
     * else
     *      max[i][j] = 0;
     */
   }//fin for - i

   /* Construction de la matrice d'extrema min qui indique les positions de tous les
   * minima sur une colonne.
   * Sa construction se fait identiquement à la construction de la matrice d'extréma max.
   * Donc, 2 sous-problèmes:
   *   SP4: recherche du minimum sur une colonne
   *   SP5: marquer tous les minimas sur une colonne
   */
   for (j=0; j<m; j++){
     // SP4
     extrema=A[0][j];
     for(i=1; i<n; i++){
       if (A[i][j]<extrema)
        extrema=A[i][j];
     }//fin for - i

     // SP5
     for (i=0; i<n; i++)
      min[i][j] = (A[i][j]==extrema);
   }//fin for - j

   /*
   * SP6: affichage des résultats.
   * Solution: les composantes qui sont marquées comme extréma dans 'max' et 'min'
   * sont des points-cols.
   */
   for(compteur=0, i=0; i<n; i++){
     for(j=0; j<m; j++){
       if (max[i][j]&&min[i][j]){
         compteur++;
         printf("point-col.: (%hu,%hu): %d\n", i, j, A[i][j]);
       }
     }//fin for - j
   }//fin for - compteur

   if(compteur==0)
   printf("Le tableau ne contient pas de points-cols.\n");
}//fin programme
