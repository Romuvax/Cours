/*
 * Chapitre 4: Structures de Données
 * Tableaux Uni. -- Exercice 6 (crible d'Erastothène)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: tableau à N valeurs entières de 1 à N
 *  - Output: les nombres premier de 1 à N ont été affichés
 *  - Caractérisation des Inputs
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 500; (car valeur donnée par l'énoncé)
 *      tab est un tableau d'entiers
 *        int tab[N];
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau (énumération et action)
 *  - SP2: affichage des nombres premiers (réalisation d'une action)
 *  - SP3: élimination des multiples de tab[i] dans tab[i+1 ... N-1] (réalisation d'une action)
 *
 * Enchaînements des SPs:
 *  SP1 -> (SP3 \inclus_dans SP2)
 */

 int main(){
   const unsigned short N = 500;

   int tab[N];

   unsigned short i, j;

   /*
   * SP 1: remplissage du tableau.  Le tableau sera rempli comme suit:
   * for_all i, 0<=i<=N-1, tab[i] = i
   *
   * Invariant Graophique:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <------------>
   *          rempli       à remplir
   *          de sorte que
   *          tab[j] = j, 0 <= j <= i-1
   *
   *
   * Fonction de Terminaison: N-i
   */
   i = 0;
   while(i< N){
     tab[i] = i;
     i++;
   }//fin while - i

   /*
   * Crible d'Eratosthène.
   * Comme notre tableau commence avec les valeurs 0 et 1 dans les 2
   * premiers indices, on va commencer à partir de la 3ème case du tableau
   */

   /*
   * SP2: affichage des nombres premiers.
   *
   *
   * Définition SP2:
   *  - Input: tab, un tableau à N valeurs entières (tableau donné par le SP1)
   *  - Output: les nombres premiers du tableau tab sont affichés
   *  - Caractérisation des Inputs:
   *    tab, N (cfr. Définition du Problème)
   *
   *
   * Représentation graphique de l'Output du SP2:
   *
   *       |0                    N-1|N
   *       +------------------------+
   * tab:  |                        |
   *       +------------------------+
   *        <---------------------->
   *       les nombres premiers contenus dans le tableau
   *       ont été affichés à l'écran
   *        <---------------------->
   *              inchangé
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *                   <------------>
   *                   encore à afficher
   *        <-------->
   *       les nombres
   *       premiers tab[0...i-1]
   *       ont été affichés à
   *       l'écran
   *        <---------------------->
   *              inchangé
   *
   *
   * Fonction de Terminaison: N-i
   */
   printf("%d\n", tab[1]);
   i = 2;
   while(i<N){
     if(tab[i]!=0){
       printf("%d\n", tab[i]);

       /*
       * SP 3: élimination des multiples de tab[i]
       *
       *
       * Définition SP3:
       *  - Input: tab, un tableau à N valeurs entières (tableaudonné par le SP1)
       *  - Output: les multiples de tab[i] dans tab[i+1...N-1] ont été remplacés par 0.
       *  - Caractérisation des Inputs:
       *    tab, N (cfr. Définition du Problème)
       *    i, position à partir de laquelle il faut partir (SP2)
       *      unsigned short i;
       *
       * Représentation graphique de l'output du SP3:
       *
       *       |0         |i |         N-1|N
       *       +----------+--+------------+
       * tab:  |          |  |            |
       *       +----------+--+------------+
       *        <-----------> <---------->
       *          inchangé    les multiples de tab[i]
       *                      dans tab[i+1 ... N-1] ont
       *                      été remplacés par 0
       *
       *
       * Invariant Graphique:
       *
       *       |0         |i |     |j   N-1|N
       *       +----------+--+-----+-------+
       * tab:  |          |  |     |       |
       *       +----------+--+-----+-------+
       *        <----------->       <------>
       *          inchangé            à traiter
       *                     <---->
       *                    les multiples de tab[i]
       *                    dans tab[i+1 ... j-1] ont
       *                    été remplacés par 0
       *
       *
       * Fonction de Terminaison:
       * N-1-j
       */
       j = i+1;
       while(j<N-1){
         if(tab[j]%i==0)
          tab[j] = 0;
         j++;
       }//fin while - j
     }//fin if
     i++;
   }//fin while - i
 }//fin programme
