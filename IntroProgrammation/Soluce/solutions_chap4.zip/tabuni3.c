/*
 * Chapitre 4: Structures de Données
 * Tableaux Uni. -- Exercice 3 (produit scalaire de 2 vecteurs)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: deux vecteurs à N valeurs entières
 *  - Output: le produit scalaire de X et Y affiché à l'écran
 *  - Caractérisation des Inputs:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 5; (note: la valeur 5 est donnée à titre indicatif)
 *      X est un tableau d'entiers
 *        int X[N];
 *      Y est un tableau d'entiers
 *        int Y[N];
 *
 * Analyse du Problème:
 *  - SP1: remplissage du vecteur X (énumération et action)
 *  - SP2: remplissage du vecteur Y (énumération et action)
 *  - SP3: calcul du produit scalaire (réalisation d'une action)
 *  - SP4: affichage du résultat à l'écran (affichage à l'écran)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 *
 *
 * Définition SP1 (le SP2 sera identique):
 *  - Input: N, la taille du vecteur
 *  - Output: le vecteur X est rempli de N valeurs lues au clavier
 *  - Caractérisation des Inputs:
 *    N, X (cfr. Définition du Problème)
 *
 *
 * Représentation graphique de l'Output du SP1 (le SP2 sera identique):
 *
 *       |0                    N-1|N
 *       +------------------------+
 * X:    |                        |
 *       +------------------------+
 *        <---------------------->
 *            rempli au clavier
 *
 *
 * Définition SP3:
 *  - Input: vecteurs X et Y à N valeurs (obtenus des SP1 et SP2)
 *  - Output: produit contient le produit scalaire de X par Y
 *  - Caractérisation des Inputs
 *    X, Y, N (cfr. Définition du Problème)
 *    produit, entier (pour le produit scalaire)
 *      int produit;
 *
 *
 * Représentation graphique de l'Output du SP3:
 *
 *       |0                    N-1|N
 *       +------------------------+
 * X:    |                        |
 *       +------------------------+
 *        <----------------------->
 *          produit scalaire effectué dans produit
 *        <---------------------->
 *              inchangé
 *
 *       |0                    N-1|N
 *       +------------------------+
 * Y:    |                        |
 *       +------------------------+
 *        <----------------------->
 *          produit scalaire effectué dans produit
 *        <---------------------->
 *              inchangé
 */

 int main(){
   //taille de mes vecteurs
   const unsigned short N = 5;

   //mon produit scalaire
   int produit = 0;

   //mes vecteurs
   int X[N];
   int Y[N];

   unsigned short i;


   /*
   * SP 1: remplir le vecteur {X} avec {N} valeurs entières lues au
   * clavier.
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * X:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          rempli       encore
   *        au clavier    à remplir
   *
   *
   * Fonction de Terminaison: N-i
   */
   printf("Remplissage du vecteur X: \n");
   for(i=0; i<N; i++){
     printf("Entrez la %dème valeur du vecteur X: ", (i+1));
     scanf("%d", &X[i]);
   }//fin for - i

   /*
   * SP 1: remplir le vecteur {Y} avec {N} valeurs entières lues au
   * clavier.
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * Y:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          rempli       encore
   *        au clavier    à remplir
   *
   *
   * Fonction de terminaison: N-i
   */
   printf("Replissage du vecteur Y: \n");
   for(i=0; i<N; i++){
     printf("Entrez la %dème valeur du vecteur Y: ", (i+1));
     scanf("%d", &Y[i]);
   }//fin for - i

   /*
   * SP 3: calcul du produit scalaire
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * X:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          produit       encore
   *         effectué    à multiplier
   *        <---------------------->
   *              inchangé
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * Y:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          produit       encore
   *         effectué    à multiplier
   *        <---------------------->
   *              inchangé
   *
   * produit effectué?
   *    produit = X[0]*Y[0] + X[1]*Y[1] + ... + X[i-1]*Y[i-1]
   *
   *
   * Fonction de Terminaison: N-i
   */
   i = 0;
   while(i<N){
     produit += X[i]*Y[i];
     i++;
   }//fin while -- i

   //SP 4: Affichage du résultat
   printf("Le résultat du produit scalaire est: %d\n", produit);
}//fin programme
