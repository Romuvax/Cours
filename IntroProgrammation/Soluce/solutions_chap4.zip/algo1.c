/*
 * Chapitre 4: Structures de Données
 * Algo. tableaux -- Exercice 1 (Distance de Hamming)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: deux tableaux d'entiers
 *  - Output: distance de hamming entre les tableaux
 *  - Caractérisation des Inputs
 *      U, un tableau d'entiers
 *      V, un tableau d'entiers
 *      N, la taille des tableaux U et V
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau U (énumération et action)
 *  - SP2: remplissage du tableau V (énumération et action)
 *  - SP3: calcul de la distance de Hamming entre U et V (réalisation d'une action)
 *  - SP4: affichage de la distande de Hamming entre U et V (affichage à l'écran)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */

int main(){
  const unsigned short N = 10;

  int U[N];
  int V[N];

  unsigned int distance = 0;
  unsigned short i;

  /*
   * SP 1: remplir le tableau {U} avec {N} valeurs entières lues au
   * clavier.
   *
   *
   * Définition SP1:
   *  - Input: N, la taille du vecteur U
   *  - Output: U est rempli avec N valeurs lues au clavier
   *  - Caractérisation des Inputs:
   *    N, U (cfr. Définition du Problème)
   *
   *
   * Représentation graphique de l'Output du SP1:
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * U:    |          |             |
	 *       +----------+-------------+
	 *        <---------------------->
	 *            rempli au clavier
   *
   *
   * Invariant Graphique:
	 *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * U:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
   *
	 * Fonction de Terminaison: N-i
   */
  i = 0;
  while(i<N){
    printf("Entez la %deme valeur du tableau: ", i+1);
    scanf("%d", &U[i]);
    i++;
  }//fin while - i

  /*
   * SP 2: remplir le tableau {V} avec {N} valeurs entières lues au
   * clavier.
   *
   *
   * Défintion SP2: idem SP1
   *
   *
   * Invariant Graphique:
	 *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * V:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
   *
	 * Fonction de Terminaison: N-i
   */
  i = 0;
  while(i<N){
    printf("Entez la %deme valeur du tableau: ", i+1);
    scanf("%d", &V[i]);
    i++;
  }//fin while - i

  /*
   * SP 3: Calcul de la distance de Hamming entre U et V
   *
   *
   * Définition SP3:
   *  - Input: U et V, deux vecteurs de N valeurs entières (obtenus du SP1 et SP2)
   *  - Output: distance contient la distance de hamming entre U et V
   *  - Caractérisation des Inputs:
   *    U, V, N (cfr. Définition du Problème)
   *    distance, naturel (accumulateur pour la distance de hamming)
   *      unsigned int distance;
   *
   *
   * Représentation graphique de l'Output du SP3:
   *
   *       |0                    N-1|N
	 *       +------------------------+
	 * U:    |                        |
	 *       +------------------------+
	 *        <---------------------->
   *         distance de hamming avec V contenue dans distance
	 *        <---------------------->
   *                inchangé
   *
   *       |0                    N-1|N
	 *       +------------------------+
	 * V:    |                        |
	 *       +------------------------+
	 *        <---------------------->
   *         distance de hamming avec U contenue dans distance
	 *        <---------------------->
   *                inchangé
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * U:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
   *                      à explorer
   *         distance de
   *         hamming avec V déjà contenue dans distance
   *        <---------------------->
   *                inchangé
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * V:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
   *                      à explorer
   *         distance de
   *         hamming avec U déjà contenue dans distance
   *        <---------------------->
   *                inchangé
   *
   *
   * Fonction de Terminaison: N-i
   */
  i = 0;
  while(i<N){
    if(U[i]!=V[i])
      distance++;
    i++;
  }//fin while - i

  //SP 4: affichage à l'écran de la distance de Hamming entre {U} et {V}
  printf("La distance de Hamming entre U et V est: %u\n", distance);
}//fin programme
