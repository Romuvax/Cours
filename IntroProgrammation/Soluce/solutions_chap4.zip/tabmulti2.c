/*
 * Chapitre 4: Structures de Données
 * Tableaux Multi. -- Exercice 2 (Mise à 0 de la diagonale d'une matrice)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: matrice d'entiers de dimension NxN
 *  - Output: affichage de la matrice avec la diagonale à 0
 *  - Caractérisation des Inputs:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 3;
 *      matrice est une matrice (carrée) de valeurs entières.
 *        int matrice[N][N];
 *
 * Analyse du Problème:
 *  - SP1: remplissage de la matrice.  On peut, bien entendu, décomposer ce SP
 *      en deux SPs (un pour la gestion des lignes, un autre pour le remplissage des
 *      colonnes de la ligne courante.
 *  - SP2: affichage de la matrice.  On peut, bien entendu, décomposer
 *      ce SP en deuc SPs (un pour l'énumération des lignes, un autre pour l'affichage des
 *      colonnes de la ligne courante).
 *  - SP3: mise de la diagonale à 0
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP2
 */

int main(){
  //dimension de la matrice carrée
  const unsigned short N = 3;

  //la matrice
  int matrice[N][N];

  unsigned short i, j;

  /*
   * SP1: remplissage de la matrice.
   *
   */
  /*
   * SP1.a: énumération & remplissage des lignes de la matrice
   *
   *
   * Invariant Graphique:
   *
   *               |0                    N-1|N
   *               +------------------------+ ––
   *              0|                        |   |
   *               |                        |   | matrice remplie au clavier
   *               ...        ...         ...   |
   *  matrice:  i-1|                        | __|
   *            ------------------------------------
   *              i|                        | --
   *               ...        ...         ...   |
   *            N-1|                        |   |  encore à remplir
   *               +------------------------+ ––
   *              N
   *
   * Fonction de Terminaison: N-i
   */
  for(i=0; i<N; i++){
    /*
     * SP1.b: remplissage des colonnes de la ligne d'indice i
     *
     *
     * Invarint Graphique:
     *
     *              |0         |j         N-1|N
  	 *              +----------+-------------+
  	 * matrice[i]:  |          |             |
  	 *              +----------+-------------+
  	 *               <--------> <----------->
  	 *                 rempli       à remplir
  	 *                 au clavier
     *
     *
     * Fonction de Terminaison: N-j
     */
    for(j=0; j<N; j++){
      printf("Elément[%hu][%hu] : ", i, j);
      scanf("%d", &matrice[i][j]);
    }//fin for - j
  }//fin for - i

  /*
   * SP2: affichage de la matrice
   *
   * Invariant(s): cfr. Exercice 1 sur les tableaux multidimensionnels
   */
  printf("Matrice donnée :\n");
  for (i=0; i<N; i++){
    for(j=0; j<N; j++)
      printf("%3d", matrice[i][j]);
    printf("\n");
  }//fin for - i

  /*
   * SP3: mise à zéro de la diagonale principale
   *
   *
   * Invariant Graphique:
   *               |0                    N-1|N
   *              -+------------------------+ ––
   *              0|                        |   |
   *               |                        |   | diagonale remplie de 0
   *               ...        ...         ...   |
   *  matrice:  i-1|                        | __|
   *            --------------------------------
   *              i|                        | --
   *               ...        ...         ...   |
   *            N-1|                        |   |  encore à remplir
   *              -+------------------------+ ––
   *              N
   *
   *
   * Fonction de Terminaison: N-i
   */
  for(i=0; i<N; i++)
    matrice[i][i]=0;

  /*
   * SP2: affichage de la matrice
   *
   * Invariant(s) & Fonction(s) de Terminaison:
   *    cfr. Exercice 1 sur les tableaux multidimensionnels
   */
  printf("Matrice donnée :\n");
  for (i=0; i<N; i++){
    for(j=0; j<N; j++)
      printf("%3d", matrice[i][j]);
    printf("\n");
  }//fin for - i
}//fin programme
