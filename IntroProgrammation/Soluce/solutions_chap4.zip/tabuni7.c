/*
 * Chapitre 4: Structures de Données
 * Tableaux Uni. -- Exercice 7 (notes d'étudiants)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>
#include <stdlib.h>  //pour la génération de nombre aléatoire (i.e., les notes)

/*
 * Définition du Problème:
 *  - Input: un tableau de N notes (avec des notes entre 0 et 60)
 *  - Output: statistiques sur les notes (min, max, moyenne) sont affichées à l'écran
 *  - Caractérisation des Inputs
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 250; (valeur choisie "aléatoirement")
 *      tab est un tableau d'entiers (je considère que les notes sont des valeurs entières)
 *        unsigned short tab[N];
 *      NOTE_MIN est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short NOTE_MIN = 0;
 *      NOTE_MAX est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short NOTE_MAX = 60;
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau des notes (énumération et action)
 *  - SP2: calcul de statistiques sur les notes (réalisation d'une action)
 *  - SP3: affichage des statiques (affichage à l'écran)
 *
 * Enchaînements des SPs:
 *  SP1 -> SP2 -> SP3
 */

 int main(){
   //taille du tableau
   const unsigned short N = 250;

   //les notes min et max
   const unsigned short NOTE_MIN = 0;
   const unsigned short NOTE_MAX = 60;

   unsigned short tab[N];

   unsigned short noteMax, noteMin;
   float moyenne;

   unsigned short i, somme = 0;

   /*
   * SP 1: remplissage du tableau.
   * Pour l'exerccie, nous allons générer aléatoirement des notes entre 0 et
   * NOTE_MAX.
   * Pour ce faire, nous utilisons rand() (définie dans stdlib.h) qui génère des
   * nombres aléatoires entre 0 et +infini.  Pour rester dans les limites autorisées
   * par le problème (une note se trouve dans l'intervalle [0; 60], nous utilisons
   * NOTE_MAX et le modulo en plus de rand().
   *
   *
   * Invariant Graphique:
   *
   *        |0         |i         N-1|N
   *        +----------+-------------+
   * tab:   |          |             |
   *        +----------+-------------+
   *         <--------> <----------->
   *                        encore à remplir
   *          déjà rempli
   *          avec des notes
   *          appartenant à l'intervalle [0; NOTE_MAX]
   *
   *
   * Fonction de Terminaison: N-i
   */
   i = 0;
   while(i<N){
     tab[i] = rand()%(NOTE_MAX+1);
     i++;
   }//fin while - i


   /*
   * SP 2: calcul de statistiques sur les notes, i.e., note max, note min et calcul
   * intermédiaire (i.e., somme cumulative) pour la moyenne.
   *
   * L'Invariant est évident au vu des problèmes déjà faits et des exercices faits
   * pendant le cours théorique.
   *
   *
   * Invariant Graphique:
   *
   *        |0         |i         N-1|N
   *        +----------+-------------+
   * tab:   |          |             |
   *        +----------+-------------+
   *         <--------> <----------->
   *                        encore à explorer
   *            somme vaut
   *            la somme des notes dans tab[0...i-1]
   *            noteMax vaut la note maximum dans tab[0...i-1]
   *            noteMin vaut la note minimum dans tab[0...i-1]
   *         <--------------------->
   *                inchangé
   *
   *
   * Fonction de Terminaison: N-i
   */
   somme = tab[0];
   noteMax = tab[0];
   noteMin = tab[0];
   i = 1;
   while(i<N){
     //calcul de la somme itérative pour la moyenne
     somme += tab[i];

     //recherche du min et du max
     if(tab[i]>noteMax)
        noteMax = tab[i];
     if(tab[i]<noteMin)
        noteMin = tab[i];

     i++;
   }//fin while - i

   moyenne = somme/N;

   //SP 3: affichage des statistiques
   printf("La moyenne des notes est: %f\n", moyenne);
   printf("La note minimale est: %hu\n", noteMin);
   printf("La note maximale est: %hu\n", noteMax);
 }//fin programme
