/*
 * Chapitre 4: Structures de Données
 * Fichiers -- Exercice 4 (Mots)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <stdlib.h>

int main(){
  const unsigned short N = 20;
  char mots[N+1];

  int i;

  FILE *fp = fopen("mots.txt", "w");

  for(i=0; i<N; i++){
    printf("Entrez le %d eme mot: ", i+1);
    scanf("%s", mots);
    fprintf(fp, "%s\n", mots);
  }//fin for - i

  fclose(fp);

  fp = fopen("mots.txt", "r");

  for(i=0; i<N; i++){
    fscanf(fp, "%s", mots);
    printf("%s\n", mots);
  }//fin for - i
  fclose(fp);
}//fin programme
