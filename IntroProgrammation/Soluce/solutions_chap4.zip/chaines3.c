/*
* Chapitre 4: Structures de Données
* Chaînes de Caractères -- Exercice 3 (palindrome)
*
* @author: Benoit Donnet (ULiège)
* Mise à Jour: Septembre 2023
*/

#include <stdio.h>

/*
* Définition du Problème:
*  - Input: chaîne de max 50 caractères
*  - Output: un message indiquant si la chaîne en entrée est un palindrome ou pas?
*  - Caractérisation des Inputs
*      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
*        const unsigned short N = 50; (par définition de l'énoncé)
*      chaine est un tableau de caractères.
*        char chaine[N+1];
*
* Analyse du Problème:
*  - SP1: lire la chaîne au clavier (lecture au clavier)
*  - SP1: déterminer la taille de la chaîne de caractères (réalisation d'une action)
*  - SP2: déterminer si la chaîne est un palindrome (réalisation d'une action)
*
* Enchaînement des SPs:
*  SP1 -> SP2 -> SP3
*/

int main(){
  const unsigned short N=50;
  char chaine[N+1];
  unsigned short debut, fin, lu = 0, est_palindrome;

  //SP1: lire la chaîne de caractères
  printf("Entrez la chaîne de caractères (sans espace): ");
  scanf("%50s", chaine);

  /*
   * SP2: trouver la taille réelle de la chaîne de caractères
   *
   * Invariant Graphique:
   *
	 *          |0         |lu         | N|N+1
	 *          +----------+-----------+--+
	 *      s:  |          |           |\0|
	 *          +----------+-----------+--+
	 *           <--------> <---------->
   *                          à parcourir
   *            s contient
   *            lu caractères utiles
	 *           <--------------------->
   *                  inchangé
   *
   *
   * Fonction de Terminaison: N+1-lu
   */
  while(chaine[lu]!='\0')
      lu++;

  /*
   * SP3: déterminer si c'est un palindrome
   *
   * Idée pour la solution: on va parcourir la chaîne de caractères en étau
   * (cfr. exercice sur le renversement de tableau -- algo4.c)
   *
   * Invariant Graphique:
   *
   *          |0      |debut  fin|       |lu    | N|N+1
	 *          +-------+----------+-------+------+--+
	 * chaine:  |       |          |       |      |\0|
	 *          +-------+----------+-------+------+--+
   *          <------> <--------> <-----> <------->
   *                   à vérifier             non exploré
   *         vérifié                 vérifié
   *          (est_palindrome)       (est_palindrome)
   *          <----------------------------------->
   *                    inchangé
   *
   *
   * Fonction de terminaison: fin+1-debut
   */

  fin = lu - 1;
  debut = 0;
  est_palindrome=1;
  while(debut<=fin && est_palindrome){
      if(chaine[debut]!=chaine[fin])
          est_palindrome = 0;
      fin--;
      debut++;
  }//fin while

  if(est_palindrome)
    printf("Palindrome.\n");
  else
    printf("Pas un palindrome\n");
}//fin programme
