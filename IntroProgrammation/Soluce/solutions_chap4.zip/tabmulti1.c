/*
 * Chapitre 4: Structures de Données
 * Tableaux Multi. -- Exercice 1 (Remplissage d'une matrice triangulaire inférieure)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>

/*
 * Il s'agit ici de créer une matrice triangulaire inférieure remplie de la façon suivante:
 * sur la première ligne (forcément, par définition de la matrice triangulaire inférieure),
 * une seule colonne correspondant au chiffre 1
 * sur la 2ème ligne, 2 colonnes correspondant aux chiffres 1 et 2 etc. jusqu'à la 12ème ligne
 *
 * Définition du Problème:
 *  - Input: /
 *  - Output: matrice triangulaire inférieure affichée à l'écran.
 *  - Caractérisation des Inputs:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 12;
 *      matrice est une matrice (carrée) de valeurs entières.
 *        int matrice[N][N];
 *
 * Analyse du Problème:
 *  SP1: remplissage de la matrice tab (réaliation d'une action)
 *  SP2: affichage de la matrice tab (réalisation d'une action)
 *
 * => on peut raffiner ces 2 SPs en SPs encore plus simple:
 *
 * SP1.a: énumération & remplissage des lignes de la matrice (énumération et action)
 * SP1.b: remplissage des colonnes de la ligne courante (réalisation d'une action)
 * SP2.a: énumération des lignes de la matrice tab (énumération et action)
 * SP2.b: affichage des colonnes de la ligne courante (réalisation d'une action)
 * SP2.c: affichage d'une cellule de la matrice (affichage à l'écran)
 *
 * Enchaînement des SPs:
 *  (SP1.b \inclus_dans SP1.a) -> (SP2.b -> SP2.c \inclus_dans SP2.a)
 *
 * Note: la découpe en SPs est assez proche du problème de triangle de Pascal
 * illustré lors du cours théorique (cfr. Chapitre 5, Slides 83 -> 100)
 */

int main(){
  /*
   * Déclaration des variables
   */
  const unsigned short N = 12; //dimension de la matrice
  int matrice[N][N]; //matrice de taille NxN
  unsigned short i, j; //indices de parcourt de la matrice

  /*
   * SP1: remplissage de la matrice
   */
  /*
   * SP1.a: énumération & remplissage des lignes de la matrice
   *
   *
   * Invariant Graphique:
   *
   *               |0                    N-1|N
   *               +------------------------+ ––
   *              0|                        |   |
   *               |                        |   | matrice triangulaire inférieure
   *               ...        ...         ...   | remplie
   *  matrice:  i-1|                        | __|
   *            ------------------------------------
   *              i|                        | --
   *               ...        ...         ...   |
   *            N-1|                        |   |  encore à remplir
   *               +------------------------+ ––
   *              N
   *
   *
   * Fonction de Terminaison: N-i
   */
  for(i=0; i<N; i++){
    /*
     * SP1.b: remplissage des colonnes de la ligne d'indice i
     *
     *
     * Invarint Graphique:
     *
     *              |0         |j  i|     N-1|N
  	 *              +----------+----+--------+
  	 * matrice[i]:  |          |    |        |
  	 *              +----------+----+--------+
  	 *               <--------> <--> <------->
  	 *                 rempli    à     non rempli
  	 *                       remplir
     *
     *
     * Fonction de Terminaison: i+1-j
     */
    for(j=0; j<=i; j++){
      matrice[i][j] = (j%3)+1;
    }//fin for - j
  }//fin for - i

  /*
   * SP2: affichage de la matrice
   *
   * Les invariants pour l'affichage de la matrice (SP2.a et SP2.b) se trouvent en appliquant
   * un raisonnement sensiblement identique à ceux des SP1.a et SP1.b
   */
  for(i=0; i<N; i++){
    printf("%2d: ", i+1);
    //SP2.b
    for(j=0; j<=i; j++){
      //SP2.c
      printf("%d ", matrice[i][j]);
    }//fin for - j
    printf("\n");
}//fin for - i
}//fin programme
