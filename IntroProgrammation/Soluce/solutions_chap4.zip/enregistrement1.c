/*
 * Chapitre 4: Structures de Données
 * Enregistrement -- Exercice 1 (structure de données pour le temps)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

typedef struct{
  unsigned short heures;
  unsigned short minutes;
  unsigned short secondes;
}Duree;

int main(){
  Duree d;

  printf("Entrez les heures: ");
  scanf("%hu", &d.heures);
  printf("Entrez les minutes: ");
  scanf("%hu", &d.minutes);
  printf("Entrez les secondes: ");
  scanf("%hu", &d.secondes);

  printf("Durée: %huh:%hum:%hus\n", d.heures, d.minutes, d.secondes);
}//fin programme
