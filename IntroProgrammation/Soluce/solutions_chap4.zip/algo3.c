/*
 * Chapitre 4: Structures de Données
 * Algo. tableaux -- Exercice 3 (nombre d'occurrences de toutes les valeurs)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include <stdio.h>
#include <stdlib.h> //=> pour la génération aléatoire

/*
 * Défintion du Problème
 *  - Input: un tableau de N valeurs entières strictement positives
 *  - Output: nombre d'occurrences de chacune des valeurs du tableau est affiché
 *            à l'écran
 *  - Caractérisation des Inputs:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 50;
 *      tab est un tableau d'entiers strictement positifs (\in N_0)
 *        unsigned int tab[N];
 *
 * Afin de ne pas calculer plusieurs fois les occurences d'une même valeur
 * dans le tableau, on va utiliser un tableau intermédiaire, {occurrence},
 * dont la taille correspond au maximum de {tab} (on considère que {tab} contient
 * des valeurs dans l'intervalle [0; 9].  Par définition, la case {i}
 * de {occurrence} maintient le nombre d'occurrences pour {tab[i]}
 *
 * Analyse du Problème:
 *  - SP1: remplissage du tableau {tab} (énumération et action)
 *  - SP2: initialisation de {occurrence} (réalisation d'une action)
 *  - SP3: calcul du nombre d'occurences de {tab} et mise à jour de {occurrence} (réalisation d'une action)
 *  - SP4: affichage des différentes occurrences (affichage à l'écran)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */

int main(){
  const unsigned short N = 50;
  const unsigned short VAL_MAX = 10;

  unsigned int tab[N];
  unsigned int occurrence[VAL_MAX];

  unsigned short i;

  /*
   * SP1: remplissage du tableau.
   * Pour l'exerccie, nous allons générer aléatoirement des notes entre 0 et
   * 9.
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore à remplir
	 *        avec des valeurs
   *        \in [0, 9]
   *
   *
   * Fonction de Terminaison: N-i
   */
  i = 0;
  while(i<N){
    tab[i] = rand()%VAL_MAX;
    i++;
  }//fin while - i

  /*
   * SP2: initialisation de {occurrence}.
   *
   * Comme à chaque indice de {occurrence} correspond une somme cumulative
   * (i.e., le # d'occurrences pour {tab[i]}), il faut initialiser à 0
   * chacune des cases de {occurrence}.
   *
   *
   * Définition SP2:
   *  - Input: VAL_MAX, la valeur maximale pour les données de tab, occurrence un tableau de taille VAL_MAX
   *  - Output: occurrence est rempli de 0
   *  - Caractérisation des Inputs:
   *     VAL_MAX, une constante naturelle
   *      const unsigned short VAL_MAX = ...;
   *    occurrence, un tableau de VAL_MAX cases
   *      unsigned int occurrence[VAL_MAX];
   *
   *
   * Représentation graphique de l'Output du SP2:
   *
   *              |0              VAL_MAX-1|VAL_MAX
	 *              +------------------------+
	 * occurrence:  |                        |
	 *              +------------------------+
   *               <---------------------->
   *                    rempli de 0
   *
   *
   * Invariant Graphique:
   *
   *              |0         |i   VAL_MAX-1|VAL_MAX
	 *              +----------+-------------+
	 * occurrence:  |          |             |
	 *              +----------+-------------+
   *               <--------> <----------->
   *              rempli de 0   à remplir
   *
   *
   * Fonction de Terminaison: VAL_MAX-i
   */
  i = 0;
  while(i<VAL_MAX){
    occurrence[i] = 0;
    i++;
  }//fin while - i

  /*
   * SP 3: calcul du nombre d'occurrences.
   *
   *
   * Définition SP3:
   *  - Input: tab, tableau à N valeurs entières, occurrence tableau rempli de MAX_VAL 0 (cfr. SP1 et SP2)
   *  - Output: occurrence contient le nombre d'occurrence de chaque valeur de tab
   *  - Caractérisation des Inputs:
   *      tab, N, VAL_MAX, occurrence (cfr. SP1 et SP2)
   *
   *
   * Représentation graphique de l'Output du SP3:
   *
   *       |0                    N-1|N
   *       +------------------------+
   * tab:  |                        |
   *       +------------------------+
   *        <---------------------->
   *               inchangé
   *
   *              |0              VAL_MAX-1|VAL_MAX
	 *              +------------------------+
	 * occurrence:  |                        |
	 *              +------------------------+
   *               <---------------------->
   *             le nombre d'occurrences de chaque
   *                    valeur de tab
   *
   *
   * Invariant Graphique:
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
   *         les      encore à calculer
   *        occurrences
   *        de chaque valeur
   *        dans occurrence
   *        <---------------------->
   *               inchangé
   *
   *              |0              VAL_MAX-1|VAL_MAX
	 *              +------------------------+
	 * occurrence:  |                        |
	 *              +------------------------+
   *               <---------------------->
   *             le nombre d'occurrences de chaque
   *                    valeur de tab[0...i-1]
   *
   *
   * Fonction de Terminaison: N-i
   */
  i = 0;
  while(i<N){
    occurrence[tab[i]]++;
    i++;
  }//fin while - i

  /*
   * SP4: affichage des différentes occurrences
   *
   *
   * Invariant Graphique:
   *
   *              |0         |i   VAL_MAX-1|VAL_MAX
	 *              +----------+-------------+
	 * occurrence:  |          |             |
	 *              +----------+-------------+
	 *               <--------> <----------->
   *                affiché        encore à afficher
   *                à l'écran
	 *               <---------------------->
   *                    inchangé
   *
   *
   * Fonction de Terminaison: VAL_MAX-i
   */
  i = 0;
  while(i<VAL_MAX){
    printf("# d'occurrences de %hu: %u\n", i, occurrence[i]);
    i++;
  }//fin while - i
}//fin programme
