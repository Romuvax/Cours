/*
 * Chapitre 2: Structures de Contrôle
 * Manipulation de Boucles -- Exercice 5 (for)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

int main(){
  int n=5;
  int f=1;
  int c;

  for(c=n; c>1; c--)
    f = f*c;

  printf("%d\n", f);
}//fin programme
