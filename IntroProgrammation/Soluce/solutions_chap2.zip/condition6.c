/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 6 (correspondance entier/mois de l'année)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int mois;
  printf("Entrez une valeur entière représentant un mois de l'année: ");
  scanf("%d", &mois);

  switch(mois){
    case 1:
      printf("Janvier\n");
      break;
    case 2:
      printf("Février\n");
      break;
    case 3:
      printf("Mars\n");
      break;
    case 4:
      printf("Avril\n");
      break;
    case 5:
      printf("Mai\n");
      break;
    case 6:
      printf("Juin\n");
      break;
    case 7:
      printf("Juillet\n");
      break;
    case 8:
      printf("Aout\n");
      break;
    case 9:
      printf("Septembre\n");
      break;
    case 10:
      printf("Octobre\n");
      break;
    case 11:
      printf("Novembre\n");
      break;
    case 12:
      printf("Décembre\n");
      break;
    default:
      printf("Invalide\n");
      break;
  }//fin switch
}//fin programme
