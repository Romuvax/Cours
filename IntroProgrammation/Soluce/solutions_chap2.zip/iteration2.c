/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 2 (somme intervalle [a,b[ )
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

int main(){
  int a, b;
  int i;

  /*
  * pour un algorithme cumulatif, il faut toujours initialiser la variable
  * qui servira d'accumulateur dans la boucle
  */
  int somme = 0;

  printf("Entrez une valeur pour a et b \n");
  scanf("%d %d", &a, &b);

  /*
  * 4 étapes:
  *  1. compteur et initialisation
  *     i = a
  *  2. nombre de tours de boucle
  *     nombre de valeurs dans l'intervalle [a, b[
  *  3. Gardien de Boucle
  *     i < b (plus simple de parcourir tout l'intervalle que de compter la taille de l'intervalle)
  *  4. Corps de Boucle
  *     faire la somme des valeurs dans [a, b[
  *     incrémenter le compteur i
  */
  for(i=a; i<b; i++)
    somme += i;

  printf("Somme dans [%d, %d[ = %d \n",a, b, somme);

  /*
  * Les autres sous-questions sont laissées à titre d'exercice.
  */
}//fin programme
