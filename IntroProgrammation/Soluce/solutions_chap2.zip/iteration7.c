/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 7 (dessin d'un rectangle)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

int main(){
  int longueur, largeur;
  int i,j;

  printf("Entrez la longueur et la largeur: ");
  scanf("%d %d", &longueur, &largeur);

  //écriture de la longueur
  printf("+");
  /*
  * 4 étapes:
  *  1. compteur et initialisation
  *     i = 1
  *  2. nombre de tours de boucle
  *     longeur-2 (longeur donne le nombre de tirets)
  *  3. Gardien de Boucle
  *     i < longueur - 1
  *  4. Corps de Boucle
  *     afficher un tiret
  *     incrémenter le compteur de boucle i
  */
  for(i=1; i<longueur-1; i++)
    printf("-");
  printf("+\n");

  //écriture des largeurs
  /*
  * 4 étapes:
  *  1. compteur et initialisation
  *     i = 1
  *  2. nombre de tours de boucle
  *     largeur-1
  *  3. Gardien de Boucle
  *     i < largeur
  *  4. Corps de Boucle
  *     afficher le côté gauche du rectangle ('|’))
  *     afficher les espaces à l'intérieur (boucle!!)
  *     afficher le côté droit du rectangle ('|’))
  *     passer à la ligne
  *     incrémenter le compteur de boucle i
  */
  for(i=1; i<largeur; i++){
    printf("|");
    /*
    * 4 étapes:
    *  1. compteur et initialisation
    *     j = 1
    *  2. nombre de tours de boucle
    *     longueur-2
    *  3. Gardien de Boucle
    *     i < longueur-1
    *  4. Corps de Boucle
    *     afficher un espace
    *     incrémenter le compteur de boucle j
    */
    for(j=1; j<longueur-1; j++)
      printf(" ");
    printf("|\n");
  }//fin for - i

  //écriture de la longueur
  printf("+");

  /*
  * 4 étapes:
  *  1. compteur et initialisation
  *     i = 1
  *  2. nombre de tours de boucle
  *     longeur-2 (longeur donne le nombre de tirets)
  *  3. Gardien de Boucle
  *     i < longueur - 1
  *  4. Corps de Boucle
  *     afficher un tiret
  *     incrémenter le compteur de boucle i
  */
  for(i=1; i<longueur-1; i++)
    printf("-");
  printf("+\n");
}//fin programme
