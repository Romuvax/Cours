/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 7 (année bissextile)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int annee;

  printf("Entrez une année: ");
  scanf("%d", &annee);

  if((annee%4==0 && annee%100!=0) || annee%400==0)
    printf("Année bissextile!\n");
  else
    printf("Année non bissextile!\n");
}//fin programme
