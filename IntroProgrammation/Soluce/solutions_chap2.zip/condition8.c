/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 8 (changement d'heure)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  //Soit 23h59m59s
  int h = 23;
  int m = 59;
  int s = 59;

  //affichage de l'heure courante
  printf("L'heure actuelle est %dh%dm%ds\n", h, m, s);

  //une seconde plus
  s += 1;

  if(s==60){
    s = 0;
    m++;

    if(m==60){
      m=0;
      h++;

      if(h==24)
      h = 0;
    }
  }

  printf("Dans une seconde il sera exactement: %dh%dm%ds\n", h, m, s);
}//fin programme
