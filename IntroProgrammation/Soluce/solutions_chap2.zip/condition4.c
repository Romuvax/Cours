/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 4 (Equation du 1er degré)
 *
 * @author: Benoit Donnet et Simon Liénardy (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  double a, b;

  printf("Introduisez les valeurs pour a et b: \n");
  scanf("%lf %lf", &a, &b);

  if(a == 0.0){
    if(b == 0.0){
      //1er cas : a et b sont nuls
      printf("Tout x est solution.\n");
    }
    else{
      // 2e cas : a nul mais pas b et b = 0 -> Impossible
      printf("Aucune solution possible.\n");
    }
  }
  else{
    // Cas général
    printf("La solution est %f.\n", -b/a);
  }
}//fin programme
