/*
 * Chapitre 2: Structures de Contrôle
 * Manipulation de Boucles -- Exercice 4 (do ... while)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

int main(){
  int i = 1;

  do{
    printf("It's a long way to the top if you wanna Rock 'n' Roll!\n");
    i++;
  }while(i<=5);
}//fin programme
