/*
 * Chapitre 1: Blocs, Variables, Instructions Simples
 * Ecriture de Code -- Exercice 2 (bille de plomb)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  float h, t;

  /*
  * 1ère partie de la question
  */
  printf("Entrez une durée : ");
  scanf("%f", &t);

  h = (9.81 * t * t) / 2.0;

  printf("A t = %f, h = %f\n", t, h);

  /*
  * 2ème partie de la question
  */
  printf("Entrez la hauteur totale (en mètres) : ");
  scanf("%f", &h);

  t = sqrt(2.0 * h / 9.81);

  printf("La bille touche le sol au bout de %f secondes\n", t);
}//fin programme
