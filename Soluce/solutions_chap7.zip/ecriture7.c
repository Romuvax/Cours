/*
 * Chapitre 7: Allocation Dynamique
 * Ecriture de Code -- Exercice 7 (Rectangle)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

#include<stdio.h>
#include<stdlib.h>
#include<assert.h>

typedef struct{
  double longueur;
  double largeur;
  double perimetre;
}Rectangle;

/*
 * @pre: r est un rectangle valide
 * @post: calcule_perimere retourne le périmètre du rectangle r.  r n'est pas modifié
 */
double calcule_perimetre(Rectangle *r){
  assert(r!=NULL);
  return (r->longueur+r->largeur)*2;
}//end calcule_perimetre()

/*
 * @pre: T est un tableau de rectangles valide, position donne la 1ere position libre
 *       dans le tableau (0 <= position < n, avec n la taille du tableau)
 * @post: creer_rectangle retourne 1 si un rectangle a été créé et placé dans le tableau.  -1 sinon.
 *        T n'est pas modifié.
 */
int creer_rectangle(Rectangle *T, int position){
  assert(position>=0);
  Rectangle *r;
  double lgueur, largeur;

  r = malloc(sizeof(Rectangle));
  if(r==NULL)
    return -1;

  printf("Entrez la longueur: ");
  scanf("%lf", &lgueur);
  printf("Entez la largeur: ");
  scanf("%lf", &largeur);

  r->longueur = lgueur;
  r->largeur = largeur;

  T[position] = *r;

  return 1;
}//fin creer_rectangle()

/*
 * @pre: r est un rectangle valide
 * @post: r est affiché à l'écran.  r n'est pas modifié.
 */
void affiche(Rectangle *r){
  assert(r!=NULL);
  printf("Le rectangle a une longueur de %f, une largeur de %f et un périmètre de %f\n",
         r->longueur, r->largeur, r->perimetre);
}//end affiche()

int main(){
  int i, n;
  Rectangle *T;

  printf("Entrez la taille du tableau: ");
  scanf("%d", &n);

  T = malloc(n * sizeof(Rectangle));
  if(T == NULL)
  return -1;

  /*
   * Invariant Graphique:
   *
   *       |0         |i         n-1|n
   *       +----------+-------------+
   * T:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *        rectangles     encore à créer
   *        créés et
   *        périmètres
   *        calculés
   *
   *
   * Fonction de Terminaison: n-i
   */
  for(i=0; i<n; i++){
    creer_rectangle(T, i);
    T[i].perimetre = calcule_perimetre(&T[i]);
  }//fin for - i

  /*
   * Invariant Graphique:
   *
   *               inchangé   
   *        <---------------------->
   *       |0         |i         n-1|n
   *       +----------+-------------+
   * T:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *        rectangles     encore à afficher
   *        affichés
   *
   *
   * Fonction de Terminaison: n-i
   */
  for(i=0; i<n; i++)
    affiche(&T[i]);

  return 0;
}//fin programme
