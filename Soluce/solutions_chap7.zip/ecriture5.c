/*
 * Chapitre 7: Allocation Dynamique
 * Ecriture de Code -- Exercice 5 (Gestion d'Etudiants)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2023
 */

/*
 * Découpe en sous-problèmes:
 *  - SP1: création d'un étudiant
 *  - SP2: afficher un étudiant
 *  - SP3: afficher le contenu d'un tableau d'étudiants à l'écran
 *  - SP4: lire au clavier le nom d'un étudiant
 *  - SP5: lire au clavier le prénom d'un étudiant
 *  - SP6: lire au clavier les notes de l'étudiant
 *  - SP7: lire un étudiant au clavier
 *  - SP8: calcul de la moyenne de chaque étudiant et moyenne générale
 *  - SP9: Calcul de la position de la moyennne max dans un sous-tableau
 *  - SP10: classement des étudiants
 *  - SP11: permutation de 2 valeurs dans un tableau
 *  - SP12: position du meilleur classé dans un sous-tableau
 *  - SP13: tri du tableau d'étudiants
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <float.h>
#include <limits.h>

typedef struct{
  char *nom;
  char *prenom;
  unsigned short matricule;
  float *notes;
  float moyenne;
  unsigned int classement;
}Etudiant;

/*
 * SP1: création d'un étudiant.
 *
 * @pre: nom!=NULL, prenom!=NULL, matricule > 0, notes!=NULL
 * @post: creer_etudiant retourne un pointeur vers une structure etudiant valide.
 *        NULL en cas d'erreur.
 */
Etudiant *creer_etudiant(char *nom, char *prenom, unsigned short matricule, float *notes){
  assert(nom!=NULL && prenom!=NULL && notes!=NULL && matricule > 0);

  Etudiant *et = malloc(sizeof(Etudiant));

  if(et==NULL)
    return NULL;

  et->nom = nom;
  et->prenom = prenom;
  et->matricule = matricule;
  et->notes = notes;
  et->moyenne = 0.0;
  et->classement = 0;

  return et;
}//fin creer_etudiant()

void liberer_etudiant(Etudiant *et) {
  free(et->nom);
  free(et->prenom);
  free(et->notes);
  free(et);
}//fin liberer_etudiant()

void liberer_etudiants(Etudiant **tab, const unsigned int n) {
  int i;
  for(i=0; i<n; i++)
    liberer_etudiant(tab[i]);
}//fin liberer_tableau_etudiant()

/*
 * SP2: affiche un étudiant
 *
 * @pre: et est un étudiant valide
 * @post: l'étudiant et est affiché à l'écran.  et n'est pas modifié
 */
void affiche_etudiant(Etudiant *et){
  assert(et!=NULL);
  printf("%d.", et->classement);
  printf(" %s %s", et->prenom, et->nom);
  printf(" (matricule: %d)", et->matricule);
  printf(" - moyenne: %f\n", et->moyenne);
}//fin affiche_etudiant()

/*
 * SP3: afficher le contenu d'un tableau d'étudiants à l'écran.
 *
 * @pre: tab est un tableau valide
 * @post: le contenu de tab est affiché à l'écran.  tab n'est pas modifié
 */
void affiche_tableau(Etudiant *tab, const unsigned int n){
  int i;

  /*
   * Invariant Graphique
   *
   *              inchangé
   *        <---------------------->
   *       |0         |i         n-1|n
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          affiché       encore à afficher
   *
   *
   * Fonction de Terminaison: n-i
   */
  for(i=0; i<n; i++)
    affiche_etudiant(&tab[i]);
}//fin affiche_tableau()

/*
 * SP4: lire au clavier le nom d'un étudiant
 *
 * @pre: /
 * @post: saisir_nom_etudiant retourne un pointeur vers le nom de l'étudiant.
 *        NULL en cas d'erreur.
 */
char *saisir_nom_etudiant(){
  char *nom = malloc(31*sizeof(char));

  if(nom==NULL)
    return NULL;

  printf("Entrez le nom de l'étudiant (max. 30 caractères): ");
  scanf("%s", nom);

  return nom;
}//fin saisir_nom_etudiant()

/*
 * SP5: lire au clavier le prénom d'un étudiant.
 *
 * @pre: /
 * @post: saisir_prenom_etudiant retourne un pointeur vers le prénom de l'étudiant.
 *        NULL en cas d'erreur.
 */
char *saisir_prenom_etudiant(){
  char *prenom = malloc(21*sizeof(char));

  if(prenom==NULL)
  return NULL;

  printf("Entrez le prénom de l'étudiant (max. 20 caractères): ");
  scanf("%s", prenom);

  return prenom;
}//fin saisir_nom_etudiant()

/*
 * SP6: lire au clavier les notes de l'étudiant
 *
 * @pre: /
 * @post: saisir_notes_etudiant retourne pointeur vers les 4 notes de l'étudiant
 *        NULL en cas d'erreur.
 */
float *saisir_notes_etudiant(){
  int i;
  float *notes = malloc(4*sizeof(float));

  if(notes==NULL)
    return NULL;

  /*
   * Invariant Graphique
   *
   *         |0         |i           3|4
   *         +----------+-------------+
   * notes:  |          |             |
   *         +----------+-------------+
   *          <--------> <----------->
   *            rempli       encore à remplir
   *            au clavier
   *
   *
   * Fonction de terminaison: 4 - i
   */
  for(i=0; i<4; i++){
    printf("Introduisez la note: ");
    scanf("%f", &notes[i]);
  }//fin for - i

  return notes;
}//fin saisir_notes_etudiants()

int verifier_allocation(char *n, char *p, float *f){
  return (n!=NULL && p!=NULL && f!=NULL);
}//fin verifier_allocation()

/*
 * SP7: lire un étudiant au clavier
 *
 * @pre: n>0, tab!=NULL
 * @post: le tableau est rempli avec, au plus, n étudiants
 */
void saisir_etudiant(Etudiant *tab, const unsigned int n){
  assert(tab!=NULL && n>0);

  int i, choix;
  unsigned int matricule;
  Etudiant *et;

  char *nom, *prenom;
  float *notes;

  /*
   * Invariant Graphique:
   *
   *       |0         |i         n-1|n
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          rempli       encore
   *        au clavier    à remplir
   *
   *
   * Fonction de terminaison: n-i
   */
  for(i=0; i<n; i++){
    printf("Introduisez le matricule de l'étudiant: ");
    scanf("%d", &matricule);

    nom = saisir_nom_etudiant();
    prenom = saisir_prenom_etudiant();
    notes = saisir_notes_etudiant();

    if(!verifier_allocation(nom, prenom, notes))
      return;

    et = creer_etudiant(nom, prenom, matricule, notes);
    if(et==NULL)
      return;
    tab[i] = *et;
  }//fin for - i
}//fin saisir_etudiant()

/*
 * SP8: calcul de la moyenne de chaque étudiant et moyenne générale.
 *
 * @pre: tab!=NULL et n>0
 * @post: moyenne retourne la moyenne des étudiants.  tab n'est pas modifié.
 */
float moyenne(Etudiant *tab, const unsigned int n){
  assert(tab!=NULL && n>0);

  float somme_etudiant, somme_totale=0.0;

  int i, j;

  /*
   * Invariant Graphique:
   *
   *                inchangé
   *        <---------------------->
   *       |0         |i         n-1|n
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *         moyenne       à moyenne
   *        calculée dans
   *        tab[0...i-1].moyenne
   *        somme_totale = somme des notes
   *        des étudiants dans tab[0...i-1]
   *
   *
   * Fonction de Terminaison: n-i
   */
  for(i=0; i<n; i++){
    somme_etudiant = 0.0;
    /*
     * Invariant Graphique:
     *
     *                       inchangé
     *               <---------------------->
     *              |0         |j           3|4
     *              +----------+-------------+
     * tab[i].notes:|          |             |
     *              +----------+-------------+
     *               <--------> <----------->
     *         somme_etudiant=    à sommer
     *          tab[i].notes[0] + tab[i].notes[1] + ... + tab[i].notes[j-1]
     *
     * Fonction de terminaison: 4-j
     */
    for(j=0; j<4; j++)
      somme_etudiant += tab[i].notes[j];

    tab[i].moyenne = somme_etudiant/4;
    somme_totale += somme_etudiant;
  }//fin for - i

  return somme_totale/n;
}//fin moyenne()

/*
 * SP9: Calcul de la position de la moyennne max dans un sous-tableau.
 *
 * Adaptation de la recherche du maximum dans un tableau
 *
 * @pre: tab!=NULL, n>0, 0 <= debut < n
 * @post: position_ùax retourne la position de la moyenne maximum dans tab[debut...n-1].
 *        tab est inchangé
 */
int position_max(Etudiant *tab, const unsigned int n){
  assert(tab!=NULL && n>0);// && 0<=debut && debut<n);
  int position=0, j;
  float max = FLT_MIN; //Définit dans float.h

  for(j=0; j<n; j++){
    if(tab[j].classement!=0 && tab[j].moyenne>max){
      position = j;
      max = tab[j].moyenne;
    }
  }//fin for - i

  return position;
}//fin position_max()

/*
 * SP10: classement des étudiants.
 *
 * Adaptation du tri par sélection fait au cours
 * Cfr. Chapitre 5, Slides 73 -> 92
 *
 * @pre: tab!=NULL, n>0
 * @post: La position dans le classement de chaque étudiant est affiché (le 1er étant le
 *        majeur).  tab est inchangé.
 */
void classement(Etudiant *tab, const unsigned int n){
  assert(tab!=NULL && n>0);
  int i, pos_max;

  for(i=0; i<n; i++){
    pos_max = position_max(tab, n);
    printf("i: %d - pos_max: %d\n", i, pos_max);
    tab[pos_max].classement = i+1;
  }//fin for - i
}//fin classement()

/*
 * SP11: permutation de 2 valeurs dans un tableau.
 *
 * Adaptation du tri par sélection fait au cours
 * Cfr. Chapitre 5, Slides 73 -> 92
 *
 * @pre: tab!=NULL, n>0, 0<=i,j<n
 * @post: tab[i] <==> tab[j]
 */
void permutation(Etudiant *tab, int i, int j, const unsigned int n){
  assert(tab!=NULL && n>0 && 0<=i && i<n && 0<=j && j<n);

  Etudiant tmp = tab[i];
  tab[i] = tab[j];
  tab[j] = tmp;
}//fin permuation()

/*
 * SP12: position du meilleur classé dans un sous-tableau
 *
 * Adaptation du tri par sélection fait au cours
 * Cfr. Chapitre 5, Slides 73 -> 92
 *
 * @pre: tab!=NULL, n>0, 0 <= debut < n
 * @post: position_min_classement retourne la position du meilleur classé dans tab[debut...n-1].
 *        tab n'est pas modifié
 */
int position_min_classement(Etudiant *tab, const unsigned int n, int debut){
    assert(tab!=NULL && n>0 && 0<=debut && debut<n);
    int position=0, j;
    int min = INT_MAX;

    for(j=debut; j<n; j++){
        if(tab[j].classement<min){
            position = j;
            min = tab[j].classement;
        }
    }//fin for - i

    return position;
}//fin position_min_classement()

/*
 * SP13: tri du tableau d'étudiants
 *
 * Adaptation du tri par sélection fait au cours
 * Cfr. Chapitre 54, Slides 73 -> 92
 */
void tri(Etudiant *tab, const unsigned int n){
  int i, position;

  for(i=0; i<n; i++){
    position = position_min_classement(tab, n, i);
    permutation(tab, i, position, n);
  }//fin for - i
}//fin tri()

int main(){
  const unsigned int N = 5;
  Etudiant *tab = malloc(sizeof(Etudiant)*5);
  if(tab==NULL)
    return -1;
  float moyenne_classe;

  saisir_etudiant(tab, N);
  //    affiche_tableau(tab, N);

  moyenne_classe = moyenne(tab, N);
  printf("La moyenne de la classe est: %f\n", moyenne_classe);

  classement(tab, N);

  tri(tab, N);

  affiche_tableau(tab, N);

  liberer_etudiants(&tab, N);

  return 0;
}//fin programme
